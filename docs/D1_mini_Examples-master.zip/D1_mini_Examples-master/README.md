# D1_mini_Examples
WeMos D1, D1 R2 &amp; D1 mini Arduino Examples

For more information, see the [WeMos website](http://www.wemos.cc/) or visit the [forum](http://forum.wemos.cc/).

You can purchase the WeMos D1, D1 R2, D1 mini and various shields from our [AliExpress store](http://www.aliexpress.com/store/1331105).
